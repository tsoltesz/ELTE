
import java.awt.AlphaComposite;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.RenderingHints;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.Vector;
import javax.imageio.ImageIO;
import javax.swing.JFrame;
import java.awt.Color;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

public class GUI extends javax.swing.JFrame {
    
    BufferedImage tablakep;
    Vector <Jatekos> jatekosok;
    Tabla tabla;
    Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();   // A képernyő nagyságának lekérése 
    final int magassag=(int)(dim.height);
    final int szelesseg=(int)(dim.width);
    int kor=0;
    int aktualisjatekos=0;
    static Boolean dobott=false;
   // final int kepszelesseg=((int)szelesseg*(2/3));
    Graphics g;
    public GUI() {
        initComponents();
        
        jatekosok=new Vector <Jatekos>();
        tabla=new Tabla();
        
        
    }
    public GUI(Vector <String> vector) {
        try{
            tablakep= ImageIO.read(new File("tabla.png") );
            //tablakep=resizeImage(tablakep, szelesseg*(3/4), magassag);
        }
        catch(Exception e){
        }
        initComponents();
        
        setSize(szelesseg,magassag);   // A program teljes képernyőssé tétele
        
        jLabel2.setText(" ");
        jLabel3.setText(" ");
        jLabel4.setText(" ");
       // jPanel1.setSize((int)szelesseg*(2/3)-10,(int) (magassag*(3/4)-15));
        setLocationRelativeTo(null);
        setResizable(false);
        
        g= jPanel2.getGraphics();
        
        
        
        jatekosok=new Vector <Jatekos>();
        for (int i=0;i<vector.size();i++){    // A nevek feltöltése
            Jatekos jatekos=new Jatekos(vector.get(i),0,500000,0);
            jatekosok.add(jatekos);
        }
        tabla=new Tabla();
        
       
        
        
        
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel(){
            @Override
            protected void paintComponent(Graphics g) {
                jPanel2.setSize((int)(szelesseg*2/3),(int)(magassag));
                super.paintComponent(g);
                Image newImage = tablakep.getScaledInstance((int)(szelesseg*2/3), (int)(magassag*3/4), Image.SCALE_DEFAULT);
                //tablakep=(BufferedImage)newImage;
                g.drawImage(newImage ,0 , 0, this);}}
        ;
        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        filler2 = new javax.swing.Box.Filler(new java.awt.Dimension(0, 0), new java.awt.Dimension(0, 0), new java.awt.Dimension(32767, 0));
        jButton1 = new javax.swing.JButton();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jMenu2 = new javax.swing.JMenu();
        jMenu3 = new javax.swing.JMenu();
        jMenu5 = new javax.swing.JMenu();
        jMenu4 = new javax.swing.JMenu();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Ökonomy");
        setUndecorated(true);
        addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                formKeyReleased(evt);
            }
        });

        jPanel2.setBackground(java.awt.Color.blue);

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel2.setForeground(java.awt.Color.darkGray);
        jLabel2.setText("greg");

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel3.setForeground(java.awt.Color.darkGray);
        jLabel3.setText("greg");

        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jLabel4.setForeground(java.awt.Color.darkGray);
        jLabel4.setText("greg");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel4)
                    .addComponent(jLabel2)
                    .addComponent(jLabel3))
                .addContainerGap(771, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel2)
                .addContainerGap(55, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(filler2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(0, 565, Short.MAX_VALUE)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(filler2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(73, 73, 73))
        );

        jButton1.setText("DOB");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jMenu1.setText("Mentés");
        jMenu1.setAlignmentX(1800.0F);
        jMenuBar1.add(jMenu1);

        jMenu2.setText("Új játék");
        jMenuBar1.add(jMenu2);

        jMenu3.setMinimumSize(new java.awt.Dimension(1000, 20));
        jMenu3.setPreferredSize(new java.awt.Dimension(1800, 20));
        jMenu3.setEnabled(false);
        jMenuBar1.add(jMenu3);

        jMenu5.setText("_");
        jMenu5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jMenu5MouseClicked(evt);
            }
        });
        jMenuBar1.add(jMenu5);

        jMenu4.setBackground(java.awt.Color.red);
        jMenu4.setText("X");
        jMenu4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jMenu4MouseClicked(evt);
            }
        });
        jMenuBar1.add(jMenu4);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 897, Short.MAX_VALUE)
                .addComponent(jButton1)
                .addGap(105, 105, 105))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(355, Short.MAX_VALUE)
                .addComponent(jButton1)
                .addGap(338, 338, 338))
        );

        setSize(new java.awt.Dimension(1900, 738));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void formKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_formKeyReleased
        if(evt.getKeyCode()==27){
           new MentesGUI(this).setVisible(true);
      
        }
    }//GEN-LAST:event_formKeyReleased

    private void jMenu4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenu4MouseClicked
        new MentesGUI(this).setVisible(true);
    }//GEN-LAST:event_jMenu4MouseClicked

    private void jMenu5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenu5MouseClicked
        setExtendedState(JFrame.ICONIFIED);
        setExtendedState(getExtendedState() | JFrame.ICONIFIED);
    }//GEN-LAST:event_jMenu5MouseClicked

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
      /*  int dobottertek=Dobas();
        jatekosok.get(aktualisjatekos).setMezo(jatekosok.get(aktualisjatekos).getMezo()+dobottertek); //Ha a dobott érték+jelenlegihely nagyobb mint a legnagyobb mező helye akkor az elejére dobja
        if (jatekosok.get(aktualisjatekos).getMezo()>=tabla.getTabla().size()){
            jatekosok.get(aktualisjatekos).setMezo(jatekosok.get(aktualisjatekos).getMezo()-tabla.getTabla().size());
        }
        
        //Kocka mozog
        
        //Vege
        aktualisjatekos++;
        if(aktualisjatekos>=jatekosok.size()){
            aktualisjatekos=0;
        }*/
        Cselekves(2);
    }//GEN-LAST:event_jButton1ActionPerformed

    public static void main(String args[]) {
        
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(GUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(GUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(GUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(GUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new GUI().setVisible(false);
                KezdoGUI kezdo=new KezdoGUI();
                kezdo.setVisible(true);      
            }
        });
        
    }
    
    public int Dobas(){
        int dobott=(int)(Math.random()*6)+1;
        return dobott;
    }
    public Boolean Nyerte(){
        for (int i=0;i<jatekosok.size();i++){
            if (jatekosok.get(i).getMinden()){
                for (int j=0;j<jatekosok.size();j++){
                    if (i!=j){
                        
                    }
                }
            }
        }
        return true;
    }
    public  void Rendszer(){     //A játék menete
       
        
        
    }
    
    public void Cselekves(int mezoszam){
        jLabel4.setText(jatekosok.get(aktualisjatekos).getNev());
        jLabel3.setText(tabla.getTabla().get(mezoszam).getSzoveg());
        switch (mezoszam){
            case 0:{
                jLabel2.setText("+"+(jatekosok.get(aktualisjatekos).getFizetes()-(jatekosok.get(aktualisjatekos).getHitelertek()+jatekosok.get(aktualisjatekos).getAutobiztertek())));
            }
            case 2:{ // Ide valami felugró ablakot kéne még csinálni
                this.setEnabled(false);
                UjAllasGUI allas=new UjAllasGUI(this,jatekosok.get(aktualisjatekos).getNev());
                allas.setVisible(true);
                
            }
        }
        
                
    }
    
    public void setTextJLabel(String s){jLabel2.setText(s);}
    
    
    
    
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.Box.Filler filler2;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenu jMenu3;
    private javax.swing.JMenu jMenu4;
    private javax.swing.JMenu jMenu5;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    // End of variables declaration//GEN-END:variables
}
