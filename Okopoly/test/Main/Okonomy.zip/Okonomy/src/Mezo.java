public class Mezo {
    
    private int penz;         // A mező által szerzett/levont pénz értéke
    private String nev;       // A mező neve
    private String szoveg;    // A mező leírása
    private int szam;         // A mező száma
    private int esemenyszam; // Ez a szám segít a hivatkozásban esemény keresésnél
    
    //Beállító és Lekérő fv-k
    public final void setPenz(int p){this.penz=p;}
    public int getPenz(){return this.penz;}
    
    public final void setNev(String s){this.nev=s;}
    public String getNev(){return this.nev;}
    
    public final void setSzoveg(String s){this.szoveg=s;}
    public String getSzoveg(){return this.szoveg;}
    
    public final void setSzam(int sz){this.szam=sz;}
    public int getSzam(){return this.szam;}
    
    public final void setEsemenyszam(int sz){this.esemenyszam=sz;}
    public int getEsemenyszam(){return this.esemenyszam;}
    
    
    public Mezo (int penz, String nev, String szoveg, int szam, int esemenyszam) {
        setPenz(penz);
        setNev(nev);
        setSzoveg(szoveg);
        setSzam(szam);
        setEsemenyszam(esemenyszam);
    }
    
}
