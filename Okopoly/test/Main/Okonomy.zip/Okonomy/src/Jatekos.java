public class Jatekos {
    
    // Adatok 
    private String nev;
    private int pont, penz, kornyezetilabnyom;
    
    int fizetes;
    private int mezo;
    
    //Játékmenetét befolyásoló tényezők
    private Boolean lepes;
    
    //Vásárolható dolgok
    private Haz haz;
    private Boolean auto, hitel;
    private int autobiztositasertek, hitelertek;
    //Energiatakarékos-e
    private Boolean elektromos;
    
    //Ellenörzők
    private Boolean minden=false, max=false;
    
    //Adatokbeállítása
    public final void setNev(String s){this.nev=s;}
    public String getNev(){return this.nev;}
    
    public final void setPont(int p){this.pont=p;}
    public int getPont(){return this.pont;}
    
    public final void setPenz(int p){this.penz=p;}
    public int getPenz(){return this.penz;}
    
    public final void setFizetes(int p){this.fizetes=p;}
    public int getFizetes(){return this.fizetes;}
    
    public final void setKornyezetilabnyom(int k){this.kornyezetilabnyom=k;}
    public int getKornyezetilabnyom(){return this.kornyezetilabnyom;}
    
    public final void setMezo(int p){this.mezo=p;}
    public int getMezo(){return this.mezo;}
    
    public final void setLepes(Boolean b){this.lepes=b;}
    public Boolean getLepes(){return this.lepes;}
    
    //Kötelezőek
    public final void setHaz(){this.haz=new Haz();}
    public Haz getHaz(){return this.haz;}
    
    public final void setAuto(Boolean b){this.auto=b;}
    public Boolean getAuto(){return this.auto;}
    
    public final void setHitel(Boolean b){this.hitel=b;}
    public Boolean getHitel(){return this.hitel;}
    
    public final void setAutobiztertek(int e){this.autobiztositasertek=e;}
    public int getAutobiztertek(){return this.autobiztositasertek;}
    
    public final void setHitelertek(int e){this.hitelertek=e;}
    public int getHitelertek(){return this.hitelertek;}
    
    // Energiatakarékos dolgok
    public final void setElektromos(Boolean b){this.elektromos=b;}
    public Boolean getElektromos(){return this.elektromos;}
    
    //Ellenörizzük, hogy minden kötelezően megvásárolható elem megvane?
    public void setMinden(){
        if (haz.getTeljes() && getAuto() && !getHitel()){
            this.minden=true;
        }
    }
    public Boolean getMinden(){return this.minden;}
    
    //Ellenörizzük, hogy Mindenből a legtakarékosabb vane meg
    public void setMax(){
        if (haz.getKimaxolva() && getElektromos() && !getHitel()){
            this.max=true;
        }
    }
    public Boolean getMax(){return this.max;}
    
    //Konstruktor
    Jatekos (String nev, int pont, int penz, int k) {
        setFizetes(500000);
        setNev(nev);
        setPont(pont);
        setPenz(penz);
        setKornyezetilabnyom(k);
        setLepes(true);
        setHaz();
        setAuto(false);
        setElektromos(false);
        setAutobiztertek(0);
        setHitel(false);
        setHitelertek(0);
    }
    
}
