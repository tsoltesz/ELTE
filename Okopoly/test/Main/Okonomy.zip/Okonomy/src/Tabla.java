//Itt töltjük fel a mezőket

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.Vector;
import javax.swing.JOptionPane;

public class Tabla {
    
    private Vector <Mezo> tabla=new Vector <Mezo>();
    
    Tabla(){
      /*  Mezo m0=new Mezo(0,"START","megkapta a havi fizetését, és a bank levonta a kötelező biztosításokat",1,1);
        Mezo m1=new Mezo(0,"Séta","sétált egyet az erdőben",2,0);
        Mezo m2=new Mezo(0,"Új állás","új állás ajánlatot kapott",3,2);
        Mezo m3=new Mezo(0,"Kert","dolgozott a kertben",4,1);
        Mezo m4=new Mezo(0,"Séta","szép időre hivatkozva gyalog ment munkába",5,1);
        Mezo m5=new Mezo(0,"LOTTÓZÓ","úgy döntött, hogy szerencsét próbál",6,1);
        
        Mezo m7=new Mezo(0,"Meglepetés","meglepetés érte",8,1);
        Mezo m8=new Mezo(300,"Kosár","Vitt magával kosarat bevásárláskor",9,1);
        Mezo m11=new Mezo(0,"Szerencse","utolérte a szerencse",12,1); //esemeny random generator
        Mezo m16=new Mezo(0,"Nyeremény","felvette az előtte haladó ember által elhajított üres Sport szeletes papírt",17,1);*/
      try{
          String sor;
          BufferedReader br=new BufferedReader(new FileReader(new File("Mezoszovegek.txt")));
          while((sor=br.readLine())!=null){
              String t[]=sor.split("\t");
              Mezo m=new Mezo(0,t[1],t[2],Integer.parseInt(t[0]),0);
              tabla.add(m);
          }
      }
      catch(Exception e){
          JOptionPane.showMessageDialog(null, "Sajnálom hiba történt a játék indításakor");
          System.exit(0);
      }
    }
    
    public Vector<Mezo> getTabla(){return this.tabla;}
    
  
}
